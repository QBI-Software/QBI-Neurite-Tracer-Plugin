# @ImageJ ij
# @String (label="Input", persist=false) inputDir
# @String (label="Output", persist=false) outputDir

import sc.fiji.snt.plugin.ShollAnalysisBulkTreeCmd
import java.util.HashMap;
import java.util.List;
import java.util.Map;


input = ["directory":inputDir, "filenamePattern":"", "filterChoice":"None", "centerChoice":"Soma node(s): Ignore connectivity", "stepSize":1.0, "polynomialChoice":"None. Skip curve fitting", "polynomialDegree":0, "normalizationMethodDescription":"Automatically choose", "normalizerDescription":"Default", "plotOutputDescription":"None", "tableOutputDescription":"Detailed & Summary tables", "saveDir":outputDir]

ij.command().run(ShollAnalysisBulkTreeCmd.class, true, input)
