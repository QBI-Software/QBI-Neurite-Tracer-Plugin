#@ Context context
#@ UIService ui
#@ SNTService snt
#@ DisplayService displayservice
#@ LogService log
#@ StatusService status
#@ File(label="Directory containing your images", style="directory") input_dir


# IMPORT MODULES #
import os, sys
from sys import path
import os.path
import time
from java.lang.System import getProperty
#jython_scripts = os.path.join(getProperty('user.home'), 'Jython_scripts')
#path.append(jython_scripts)
from java import io
from sc.fiji.snt import (Path, SNTService, SNT, Tree)
from sc.fiji.snt.analysis import (SkeletonConverter, TreeAnalyzer, SNTTable)
from sc.fiji.snt.util import PointInImage
import sc.fiji.snt.plugin.ShollAnalysisBulkTreeCmd
import sc.fiji.snt.analysis.graph.DirectedWeightedGraph as dwg
from ij import IJ
from ij import gui
from ij import ImagePlus
from ij import plugin
from ij import process
from ij import WindowManager
from ij.plugin import frame as roiframe
import ij.measure.ResultsTable as RT
import ij.plugin.filter.Analyzer as AZ
import ij.plugin.filter.ParticleAnalyzer as PA
from csv import DictReader


#Ask to confirm pixel scaling
pxlscale = IJ.getNumber("Please confirm Pixel Scaling (um/px): ",0.586)

#=========================================#

#PRE-PROCESSING PARAMETERS
lowc=1;
lowi=85;
nwidth=3;
cleanup=10;

skeletonizeImp = False
pruneByLength = False
lengthThreshold = 3
connectComponents = False
maxConnectDist = 15

chosen_metrics = "Complete suite"
recursive = False
name_filter = ".TRACES"

IJ.run("Clear Results");
IJ.run("Set Measurements...", "area mean standard min modal centroid center perimeter fit shape limit redirect=None decimal=3")
IJ.setForegroundColor(0, 0, 0)
IJ.setBackgroundColor(0, 0, 0)

#=========================================#

files = []
d = str(input_dir)
for f in os.listdir(d):
	if os.path.basename(f).startswith('.'):
		continue
	if not f.lower().endswith('.tif'):
		continue
	files.append(os.path.join(d, f))


for imf in files:
	image = io.File(imf)
	imname = image.getPath()
	imp = ImagePlus(imname)
	imp.show()
	nTitle = imp.getTitle()
	nPath = imname.replace(nTitle,"")
	IJ.run("Set Scale...", "distance=1 known=0.586 unit=um")
	IJ.saveAs("Tiff", imname)
	IJ.run("Properties...", "channels=1 slices=1 frames=1 pixel_width=" + str(pxlscale) + " pixel_height=" + str(pxlscale) + " voxel_depth=0.000")
	IJ.run ('Rename...', 'title=original')
	IJ.run("Duplicate...", "title=bgremoved")
	imp_bgremoved = IJ.getImage()
	imp_bgremoved.show()
	IJ.selectWindow(imp_bgremoved.getTitle())
	IJ.run("Subtract Background...", "rolling=250 sliding")
	IJ.run("Gaussian Blur...", "sigma=1")
	IJ.run("Top Hat...", "radius=20")
	IJ.run("Enhance Local Contrast (CLAHE)", "blocksize=99 histogram=256 maximum=2 mask=*None* fast_(less_accurate)")
	IJ.selectWindow(imp_bgremoved.getTitle())
	IJ.run("Duplicate...", "title=open")
	imp_open = IJ.getImage()
	imp_open.show()
	IJ.selectWindow(imp_open.getTitle())
	time.sleep(0.1)
	IJ.run("Gaussian Blur...", "sigma=1")
	time.sleep(0.1)
	
	#FIND SOMA(S)
	IJ.setAutoThreshold(imp_open,"Minimum dark")
	IJ.run("Convert to Mask")
	IJ.run("Grays")
	IJ.run("Options...", "iterations=1 count=1 black do=Open")
	IJ.run("Options...", "iterations=1 count=1 black do=Close")
	IJ.run("Options...", "iterations=3 count=3 black do=Dilate")
	imp_soma = IJ.getImage()
	imp_soma.show()
	IJ.resetThreshold()
	
	#FIND NEURITE(S)
	imp_bgremoved.show()
	IJ.selectWindow(imp_bgremoved.getTitle())
	IJ.run("Duplicate...", "title=neuriteridges")
	imp_neuriteridges = IJ.getImage()
	imp_neuriteridges.show()
	IJ.selectWindow(imp_neuriteridges.getTitle())
	IJ.run("Ridge Detection", "line_width=5 high_contrast=200 low_contrast=50 extend_line make_binary method_for_overlap_resolution=NONE sigma=1.75 lower_threshold=0.30 upper_threshold=2.00 minimum_line_length=2 maximum=1000");
	IJ.run("Grays")
	IJ.resetThreshold()
	IJ.run("Options...", "iterations=3 count=2 black do=Dilate")
	IJ.run("Options...", "iterations=1 count=1 black do=Skeletonize")
	imp_neuriteridgeskeleton = IJ.getImage()
	imp_neuriteridgeskeleton.show()
	IJ.selectWindow(imp_neuriteridgeskeleton.getTitle())
	IJ.run("Duplicate...", "title=neuritesgaps")
	imp_neuritesgaps = IJ.getImage()
	imp_neuritesgaps.show()
	IJ.selectWindow(imp_neuritesgaps.getTitle())
	time.sleep(0.1)
	
	#JOIN DISCONNECTED NEURITE(S)
	IJ.run("Options...", "iterations=5 count=2 black do=Dilate")
	imp_neuritesbold = plugin.ImageCalculator.run(imp_soma, imp_neuritesgaps,"OR create")
	imp_neuritesbold.show()
	imp_neuritesbold = IJ.getImage()
	IJ.selectWindow(imp_neuritesbold.getTitle())
	IJ.run("Options...", "iterations=3 count=3 black do=Close")
	IJ.run("Options...", "iterations=1 count=1 black do=Skeletonize")
	time.sleep(0.1)
	imp_neuritesjoin = plugin.ImageCalculator.run(imp_neuriteridgeskeleton, imp_neuritesbold,"OR create")
	imp_neuritesjoin.show()
	imp_neuritesjoin = IJ.getImage()
	IJ.selectWindow(imp_neuritesjoin.getTitle())
	IJ.run("Options...", "iterations=1 count=2 black do=Dilate")
	IJ.run("Options...", "iterations=1 count=1 black do=Skeletonize")
	imp_neuriteSomaSkeleton = IJ.getImage()
	imp_neuriteSomaSkeleton.show()
	time.sleep(0.1)
	imp_soma.show()
	IJ.selectWindow(imp_soma.getTitle())
	IJ.run("Select None")
	imp_somaNeuriteSkeleton = plugin.ImageCalculator.run(imp_soma, imp_neuriteSomaSkeleton,"OR create")
	time.sleep(0.1)
	imp_somaNeuriteSkeleton.show()
	#IJ.selectWindow(imp_somaNeuriteSkeleton.getTitle())
	IJ.run("Particle Remover", "size=0-"+str(cleanup)+" pixel")
	time.sleep(0.1)
	IJ.run("Select None")
	IJ.run("Properties...", "channels=1 slices=1 frames=1 pixel_width=" + str(pxlscale) + " pixel_height=" + str(pxlscale) + " voxel_depth=0.000")
	IJ.run("Duplicate...", "title=fullNeuriteSkeleton")
	imp_fullNeuriteSkeleton = IJ.getImage()
	imp_fullNeuriteSkeleton.show()
	IJ.run ('Rename...', 'title=fullNeuriteSkeleton')
	IJ.run("Options...", "iterations=1 count=1 black do=Close")
	#IJ.run("Options...", "iterations=1 count=1 black do=Skeletonize")
	IJ.run("Analyze Particles...", "size=75-2000 pixel circularity=0.00-1.00 show=Nothing clear add")
	time.sleep(0.1)
	rois = roiframe.RoiManager.getInstance()
	nrois = rois.getCount()
	
	#FIND AND TRACE NEURITES FOR EACH CELL
	for r in range(nrois):
		IJ.selectWindow("fullNeuriteSkeleton")
		IJ.run("Select None")
		IJ.run("Duplicate...", "title=somaNeuriteSkeleton"+str(r)+"");
		imp_somaNeuriteSkeletonr = IJ.getImage()
		imp_somaNeuriteSkeletonr.show()
		IJ.selectWindow(imp_somaNeuriteSkeletonr.getTitle())
		time.sleep(0.1)
		IJ.run("Select All")
		IJ.run("Clear")
		IJ.selectWindow(imp_fullNeuriteSkeleton.getTitle())
		rois.select(r)
		IJ.run("Copy")
		imp_somaNeuriteSkeletonr.show()
		IJ.selectWindow(imp_somaNeuriteSkeletonr.getTitle())
		rois.select(r)
		IJ.run("Paste")
		IJ.run("Select None")
		
		#FIND CELL CENTROIDS
		IJ.run("Duplicate...", "title=soma_"+str(r)+"");
		imp_soma_r = IJ.getImage()
		imp_soma_r.show()
		IJ.selectWindow(imp_soma_r.getTitle())
		IJ.run("Options...", "iterations=1 count=1 black do=Erode")
		IJ.run("Options...", "iterations=1 count=1 black do=Dilate")
		time.sleep(0.1)
		com = RT()
		an = AZ(imp_soma_r, AZ.CENTER_OF_MASS, com)
		an.measure();
		XCOM = (com.getValue("XM",0))/pxlscale
		YCOM = (com.getValue("YM",0))/pxlscale
		com.deleteRows(0,-1)
		imp_soma_r.show()
		IJ.selectWindow(imp_soma_r.getTitle())
		time.sleep(0.1)
		IJ.run("Select All")
		IJ.run("Clear")
		IJ.setForegroundColor(255, 255, 255)
		IJ.makePoint(XCOM, YCOM)
		IJ.run("Draw")
		IJ.setForegroundColor(0, 0, 0)
		imp_soma.show()
		IJ.selectWindow(imp_soma.getTitle())
		IJ.run("Select None")
		IJ.run("Create Selection")
		IJ.selectWindow(imp_somaNeuriteSkeletonr.getTitle())
		IJ.run("Restore Selection")
		IJ.run("Clear")
		IJ.run("Select None")
		IJ.run("Particle Remover", "size=0-"+str(cleanup)+" pixel")
		IJ.run("Properties...", "channels=1 slices=1 frames=1 pixel_width=" + str(pxlscale) + " pixel_height=" + str(pxlscale) + " voxel_depth=0.000")
		
		
		#FIND ATTACHMENT(S)
		IJ.selectWindow(imp_soma.getTitle())
		IJ.run("Select None")
		IJ.run("Duplicate...", "title=soma_dilate")
		imp_somaDilate = IJ.getImage()
		imp_somaDilate.show()
		IJ.selectWindow(imp_somaDilate.getTitle())
		IJ.run("Options...", "iterations=1 black count=1 do=Dilate")
		imp_stem = plugin.ImageCalculator.run(imp_somaDilate, imp_somaNeuriteSkeletonr,"AND create")
		imp_stem.show()
		imp_stem = IJ.getImage()
		IJ.selectWindow(imp_stem.getTitle())
		IJ.run("Duplicate...", "title=stem_erode")
		imp_stemErode = IJ.getImage()
		imp_stemErode.show()
		IJ.selectWindow(imp_stemErode.getTitle())
		IJ.run("Options...", "iterations=1 black count=5 do=Erode")
		imp_stemPoints = plugin.ImageCalculator.run(imp_stem, imp_stemErode,"Subtract create")
		imp_stemPoints.show()
		imp_stemPoints = IJ.getImage()
		imp_attachmentPoints = plugin.ImageCalculator.run(imp_stemPoints, imp_soma,"Subtract create")
		imp_attachmentPoints.show()
		imp_attachmentPoints = IJ.getImage()

		#JOIN SOMA CENTRE TO NEURITE ATTACHMENT POINTS
		aprt = RT()
		appa = PA(0,64, aprt, 0, 10)
		appa.analyze(imp_attachmentPoints)
		
		imp_somaNeuriteSkeletonr.show()
		IJ.selectWindow(imp_somaNeuriteSkeletonr.getTitle())
		time.sleep(0.1)
		IJ.setForegroundColor(255, 255, 255)
		for atap in range(aprt.getCounter()):
			X_APRT = (aprt.getValue("XM",atap))
			Y_APRT = (aprt.getValue("YM",atap))
			imp_somaNeuriteSkeletonr.show()
			time.sleep(0.1)
			IJ.makeLine(XCOM,YCOM,int(X_APRT/pxlscale),int(Y_APRT/pxlscale))
			IJ.run("Draw", "slice")
			IJ.run("Select None")
		IJ.setForegroundColor(0, 0, 0)
		time.sleep(0.1)
		
		#MAKE AN IMAGE STACK WITH ATTACHMENTS AND NEURITES FOR TRACING IN SNT
		catted = [imp_soma_r, imp_soma_r, imp_somaNeuriteSkeletonr]
		imp_forTracing = plugin.Concatenator.run(catted)
		imp_forTracing.show()
		IJ.selectWindow(imp_forTracing.getTitle())
		imp_forTracing = IJ.getImage()
		IJ.run("Properties...", "channels=1 slices=3 frames=1 pixel_width=" + str(pxlscale) + " pixel_height=" + str(pxlscale) + " voxel_depth=0.000")
		time.sleep(0.2)
		
		#TRACE NEURITES
		impTitle = image.getName().replace(".tif","") + "_Cell" + str(r) + "-skeleton"
		recDir = os.path.join(nPath, impTitle)
		converter = SkeletonConverter(imp_forTracing, skeletonizeImp)
		converter.setPruneByLength(pruneByLength)
		converter.setLengthThreshold(lengthThreshold)
		converter.setConnectComponents(connectComponents)
		converter.setMaxConnectDist(maxConnectDist)
	
		try:
			trees = converter.getTrees()
		except:
			print("No neurites found")
		else:
			graph = trees[0].getGraph()
			fullTree = Tree(graph,"graph")
			startpoint = PointInImage(XCOM, YCOM, 0)
			if not os.path.isdir(recDir):
				os.mkdir(recDir)
			
			tracesPath = os.path.join(recDir, impTitle + ".TRACES")
			success = "File saved: {}".format(tracesPath) if fullTree.save(tracesPath) else "I/O Error. File not saved: {}".format(tracesPath)
			time.sleep(0.2)
			#ANALYSE THE SWC TRACINGS TO GET METRICS, SHOLL ANALYSIS, ETC.
			# Define a common table to host results
			table = SNTTable()  # a org.scijava.table.DefaultGenericTable
			# Define the metrics to be considered
			metrics = TreeAnalyzer.getMetrics()
			impTitle = image.getName().replace(".tif","") + "_Cell" + str(r) + "-skeleton"
			for (counter, tree) in enumerate(trees):
				# Prepare analysis. We'll make TreeAnalyzer aware of current context
				# so that we don't need to worry about displaying/updating the table
				analyzer = TreeAnalyzer(tree)
				analyzer.setContext(context)
				analyzer.setTable(table, 'SWC measurements: %s' % impTitle)	
				# Analyze the data grouping measurements by compartment (e.g., axon,
				# dendrite). See the analysis API for more sophisticated operations:
				# https://javadoc.scijava.org/SNT/
				analyzer.measure(metrics, True)
			table.save(nPath + impTitle + "-metrics.csv")
			
			argsForSholl = "inputdir='" + nPath + impTitle + "' outputdir='" + nPath + impTitle + "'"
			IJ.run("Sholl Bulk Analysis From Reconstructions", argsForSholl )
			time.sleep(0.9)
			IJ.run("IJ Robot", "order=KeyPress x_point=0 y_point=0 delay=100 keypress=!")

		imp_forTracing.changes = False
		imp_soma_r.changes = False
		imp_somaNeuriteSkeletonr.changes = False
		imp_stem.changes = False 
		imp_stemErode.changes = False
		imp_stemPoints.changes = False
		imp_attachmentPoints.changes = False
		imp_somaDilate.changes = False

		imp_forTracing.close()
		imp_soma_r.close()
		imp_somaNeuriteSkeletonr.close()
		imp_stem.close()
		imp_stemErode.close()
		imp_stemPoints.close()
		imp_attachmentPoints.close()
		imp_somaDilate.close()	
	
	print("Done: " + impTitle)		
	rois.reset()
	IJ.run("Close All")

